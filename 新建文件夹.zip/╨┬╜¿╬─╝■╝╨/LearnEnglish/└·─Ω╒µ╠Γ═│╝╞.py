#!/usr/bin/env python
# -*- coding:utf-8 -*-

"""
author：Simon
date：2018年7月8日 22:21:27
about：英语真题词频统计
待完善：词前后去除干扰字符；需要去除停用词；字母小写化；词形还原与词干提取
"""
import nltk
import re
from collections import Counter


def get_allwords():
    allwords = []
    with open("历年真题/所有真题.txt", "r", encoding="utf-8") as f:
        for index, line in enumerate(f):
            if index % 50 == 0:
                print(index)
            line = line.replace("\t", " ")
            words = line.strip().split(" ")
            words = [word.strip(".,“”():?;‘’!'").lower() for word in words]
            allwords.extend(words)

    return allwords


def get_wordfre(all_words):
    """
    词频统计
    :param all_words: 输入全文词列表
    :return:
    """
    assert type(all_words) == list

    cnt = Counter(all_words)
    word_fre = cnt.most_common()
    stop_words = get_lines("data/stop_words.txt")
    re_alph = re.compile("[a-zA-Z]")

    with open("results/词频统计.txt", "w+", encoding="utf-8") as out:
        out.write("总词数：{}\n".format(len(all_words)))
        count = 0
        for word, fre in word_fre:
            if word not in stop_words:
                if re_alph.search(word):
                    count += 1
                    out.write("{} {}\n".format(word, fre))

        print("词语种数：{}".format(count))
    return word_fre


def get_2gram(par_list, par_n):
    temp = nltk.ngrams(par_list, par_n)  # n-gram
    newwords_list = [" ".join(item) for item in temp]  # 词组
    cnt = Counter(newwords_list)
    words = cnt.most_common()

    with open("results/2gram词频统计.txt", "w+", encoding="utf-8") as fout:
        for item in words:
            fout.write("{}\t{}\n".format(item[0], item[1]))

    return words


def get_lines(file_path):
    """get lines"""
    with open(file_path, "r", encoding="utf-8") as f:
        line_list = []
        for line in f:
            temp = line.strip()
            if temp not in line_list:
                line_list.append(temp)

    return line_list


def main():
    allwords = get_allwords()
    word_freq = get_wordfre(allwords)
    new_words_freq = get_2gram(allwords, 2)


if __name__ == "__main__":
    main()
